Sono stati aggiunti diversi tile nuovi delle stesse dimensioni (32x32).

Dallo stesso tileset del primo livello abbiamo:
- Cespuglio (ID: 129, CROP: x = 448, y = 192)
- Roccia (ID: 95, CROP: x = 576, y = 128)

Da un altro tileset, caricato in questa directory abbiamo:
- Fiori (ID: 109, CROP: x = 32, y = 260)

Tutti questi tile devono essere SOLIDI, quindi non attraversabili dal player.