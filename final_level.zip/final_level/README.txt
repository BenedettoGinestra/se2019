Tiles di throne_room.png:
- Pavimento1 (ID: 40, CROP: x = 32, y = 512)
- Parete (ID: 42, CROP: x = 32, y = 384)
- Colonna1 (ID: 43, CROP: x = 192, y = 544)
- Colonna2 (ID: 44, CROP: x = 192, y = 576)
- Finestra1 (ID: 45, CROP: x = 128, y = 384)
- Finestra2 (ID: 46, CROP: x = 128, y = 416)
- Black (ID: 55, CROP: x = 0, y = 0)

Tiles di carpet.jpeg:
- Pavimento2 (ID: 41, CROP: x = 0, y = 0)
- ScalaST (ID: 47, CROP: x = 0, y = 128)
- ScalaCT (ID: 48, CROP: x = 64, y = 128)
- Tappeto11 (ID: 49, CROP: x = 64, y = 64)
- Tappeto12 (ID: 50, CROP: x = 96, y = 64)
- Tappeto13 (ID: 51, CROP: x = 128, y = 64)
- Tappeto21 (ID: 52, CROP: x = 64, y = 96)
- Tappeto22 (ID: 53, CROP: x = 96, y = 96)
- Tappeto23 (ID: 54, CROP: x = 128, y = 96)

Tiles di throne.png:
- Throne1 (ID: 55, CROP: x = 0, y = 0)
- Throne2 (ID: 56, CROP: x = 0, y = 32)