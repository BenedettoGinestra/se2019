Sono stati aggiunti diversi tile nuovi delle stesse dimensioni (32x32).

Da castle_tileset.jpg abbiamo:
- Pavimento (ID: 57, CROP: x = 160, y = 96)
- Water tile (ID: 81, CROP: x = 64, y = 256) DA AGGIORNARE SOLTANTO
- Muro fine mappa sx (ID: 35, CROP: x = 0, y = 32)
- Muro fine mappa bot (ID: 36, CROP: x = 32, y = 352)
- Muro fine mappa dx (ID: 37, CROP: x = 512, y = 320)
- Muro separatore (ID: 38, CROP: x = 96, y = 64)
- Muro top1 (ID: 1, CROP: x = 288, y = 0)
- Muro top2 (ID: 2, CROP: x = 288, y = 32)

Da candle2.png abbiamo:
- Candela (ID: 39, CROP: x = 0, y = 0)

Tutti questi tile devono essere SOLIDI, quindi non attraversabili dal player.
(TRANNE IL PAVIMENTO E LA CANDELA)