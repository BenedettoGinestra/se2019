/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame.gfx;

import java.awt.image.BufferedImage;

/**
 *
 * @author Clover
 */
public class Assets {
    
    private static final int width = 28, height = 37;
    private static final int width2 = 35, height2 = 40;
    
    public static BufferedImage invisible;
    public static BufferedImage[] player_idle;
    public static BufferedImage[] player_right;
    
    public static BufferedImage grass;
    public static BufferedImage ground;
    public static BufferedImage[] trees = new BufferedImage[16];
    public static BufferedImage water;
    
    public static void init() {
        SpriteSheet sheet = new SpriteSheet(ImageLoader.loadImage("/textures/sheet.png"));
        SpriteSheet tileset = new SpriteSheet(ImageLoader.loadImage("/textures/tileset.png"));
        SpriteSheet final_tileset = new SpriteSheet(ImageLoader.loadImage("/textures/Forest Tileset.png"));
        
        player_idle = new BufferedImage[3];
        player_right = new BufferedImage[10];
        
        //CHARACTER IDLE ANIMATION
        player_idle[0] = sheet.crop(4, 5, width, height);
        player_idle[1] = sheet.crop(40, 5, width, height);
        player_idle[2] = sheet.crop(80, 5, width, height);
        
        //CHARACTER RIGHT MOVEMENT
        player_right[0] = sheet.crop(4, 96, width, height);
        player_right[1] = sheet.crop(35, 96, width + 2, height);
        player_right[2] = sheet.crop(78, 96, width + 6, height);
        player_right[3] = sheet.crop(127, 96, width, height);
        player_right[4] = sheet.crop(160, 96, width, height);
        player_right[5] = sheet.crop(195, 96, width, height);
        player_right[6] = sheet.crop(226, 96, width, height);
        player_right[7] = sheet.crop(263, 96, width, height);
        player_right[8] = sheet.crop(303, 96, width, height);
        player_right[9] = sheet.crop(340, 96, width, height);
        
        invisible = tileset.crop(0, 0, 16, 16);
        
        grass = final_tileset.crop(32, 32, 32, 32);
        
        ground = final_tileset.crop(128, 32, 32, 32);
        
        trees[0] = final_tileset.crop(0, 288, 32, 32);
        trees[1] = final_tileset.crop(32, 288, 32, 32);
        trees[2] = final_tileset.crop(64, 288, 32, 32);
        trees[3] = final_tileset.crop(96, 288, 32, 32);
        trees[4] = final_tileset.crop(0, 320, 32, 32);
        trees[5] = final_tileset.crop(32, 320, 32, 32);
        trees[6] = final_tileset.crop(64, 320, 32, 32);
        trees[7] = final_tileset.crop(96, 320, 32, 32);
        trees[8] = final_tileset.crop(0, 352, 32, 32);
        trees[9] = final_tileset.crop(32, 352, 32, 32);
        trees[10] = final_tileset.crop(64, 352, 32, 32);
        trees[11] = final_tileset.crop(96, 352, 32, 32);
        trees[12] = final_tileset.crop(0, 384, 32, 32);
        trees[13] = final_tileset.crop(32, 384, 32, 32);
        trees[14] = final_tileset.crop(64, 384, 32, 32);
        trees[15] = final_tileset.crop(96, 384, 32, 32);
        
        water = final_tileset.crop(128, 128, 32, 32);

    }   
}