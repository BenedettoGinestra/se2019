/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame.tileset;

import mygame.gfx.Assets;

/**
 *
 * @author Clover
 */
public class GrassTile extends Tile {
    
    public GrassTile(int id) {
        super(Assets.grass, id);
    }
    
    @Override
    public boolean isSolid() {
        return false;
    }
}
