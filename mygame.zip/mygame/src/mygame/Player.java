/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

import mygame.gfx.Assets;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import mygame.gfx.Animation;

/**
 *
 * @author Clover
 */
public class Player extends Creature {
    
    //ANIMATIONS
    private Animation idle_animation, right_animation;
    
    public Player(Handler handler, float x, float y) {
        super(handler, x, y, Creature.DEAULT_CREATURE_WIDTH, Creature.DEAULT_CREATURE_HEIGHT);
        
        bounds.x = 4;
        bounds.y = 3;
        bounds.height = 61;
        bounds.width = 32;
        
        idle_animation = new Animation(250, Assets.player_idle);
        right_animation = new Animation(100, Assets.player_right);
    }

    @Override
    public void tick() {
        
        idle_animation.tick();
        right_animation.tick();
        
        getInput();
        move();
        handler.getGameCamera().centerOnEntity(this);
    }
    
    public void getInput() {
        xMove = 0;
        yMove = 0;
        
        if(handler.getKeyManager().up)
            yMove = -speed;
        if(handler.getKeyManager().down)
            yMove = speed;
        if(handler.getKeyManager().right)
            xMove = speed;
        if(handler.getKeyManager().left)
            xMove = -speed;
        
    }

    @Override
    public void render(Graphics g) {
        g.drawImage(getCurrentAnimationFrame(), (int) (x - handler.getGameCamera().getxOffset()), (int) (y - handler.getGameCamera().getyOffset()), width, height, null);
    }
    
    private BufferedImage getCurrentAnimationFrame() {
        if(xMove > 0) {
            return right_animation.getCurrentFrame();
        }
        else {
            return idle_animation.getCurrentFrame();
        }
    }
}