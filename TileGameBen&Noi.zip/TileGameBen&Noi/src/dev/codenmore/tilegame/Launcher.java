package dev.codenmore.tilegame;

public class Launcher {

    public static void main(String[] args) {

        Game game = new Game("Tile Game!");

        game.start();

        /*
            LevelHandler lh=new LevelHandler();
            lh.start();
         */
    }

}
