package dev.codenmore.tilegame;

import java.awt.Graphics;
import java.awt.image.BufferStrategy;

import dev.codenmore.tilegame.display.Display;
import dev.codenmore.tilegame.gamegui.*;
import dev.codenmore.tilegame.gfx.Assets;
import dev.codenmore.tilegame.gfx.GameCamera;
import dev.codenmore.tilegame.input.KeyManager;
import dev.codenmore.tilegame.input.MouseManager;
import dev.codenmore.tilegame.levels.BossLevel;
import dev.codenmore.tilegame.levels.Level;
import dev.codenmore.tilegame.levels.LevelHandler;
import dev.codenmore.tilegame.levels.WorldLevel;
import dev.codenmore.tilegame.worlds.World;
import java.io.IOException;
import java.util.LinkedList;
import java.util.logging.Logger;

public class Game implements Runnable {

    private Display display;
    private int width, height;
    public String title;

    private static boolean running = false;
    private static Thread thread;

    private BufferStrategy bs;
    private Graphics g;

    //Input
    private KeyManager keyManager;
    private MouseManager mouseManager;

    //Camera
    private GameCamera gameCamera;

    //Handler
    private Handler handler;

    private GameGUI gui;

    private LevelHandler lh;

    //FPS SETTINGS
    private int fps = 60;
    private double timePerTick = 1000000000 / fps;
    private double delta = 0;
    private long now;
    private long lastTime;
    private long timer = 0;
    private int ticks = 0;

    public Game(String title) {
        this.title = title;
        keyManager = new KeyManager();
        //mouseManager = new MouseManager();
    }

    private void init() throws IOException {

        //GUI initialization
        this.gui = new GameGUI();
        GameScenePanel gameScene = (GameScenePanel) this.gui.getGameScenePanel();
        this.width = gui.getCanvas().getSize().width;
        this.height = gui.getCanvas().getSize().height;

        gui.getFrame().addKeyListener(keyManager);

        Assets.init();

        handler = new Handler(this);
        gameCamera = new GameCamera(handler, 0, 0);

        //level handler initialization
        lh = new LevelHandler(this.createLevelSequence(), handler);

    }

    private void tick() {
        keyManager.tick();

        if (lh.getLevel() != null) {
            lh.getLevel().tick();
        }
    }

    private void render() {
        bs = gui.getCanvas().getBufferStrategy();
        if (bs == null) {
            gui.getCanvas().createBufferStrategy(3);
            return;
        }
        g = bs.getDrawGraphics();

        //Clear Screen
        g.clearRect(0, 0, gui.getCanvas().getSize().width, gui.getCanvas().getSize().height);
        //Draw Here!

        if (lh.getLevel() != null) {
            lh.getLevel().render(g);
        }
        //End Drawing!
        bs.show();
        g.dispose();
    }

    public void run() {

        try {
            init();
        } catch (IOException ex) {
            Logger.getLogger(Game.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            System.exit(1);
        }

        lastTime = System.nanoTime();

        while (running) {

            fps();

            lh.checkPlayerLives();

        }

        stop();

    }

    public KeyManager getKeyManager() {
        return keyManager;
    }

    public MouseManager getMouseManager() {
        return mouseManager;
    }

    public GameCamera getGameCamera() {
        return gameCamera;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public synchronized void start() {
        if (running) {
            return;
        }
        running = true;
        thread = new Thread(this);
        thread.start();
    }

    public synchronized void stop() {
        if (!running) {
            return;
        }
        running = false;
        thread.interrupt();

    }

    //inizialization of the level sequence, managed by the level handler
    public LinkedList<Level> createLevelSequence() {
        LinkedList<Level> l = new LinkedList<Level>();
        WorldLevel wl;
        BossLevel bl;

        wl = new WorldLevel(0, new World(handler, "res/worlds/world1.txt"), handler);
        bl = new BossLevel(1, new World(handler, "res/worlds/world2.txt"), handler);

        l.add(wl);
        l.add(bl);

        return l;
    }

    public void fps() {
        now = System.nanoTime();
        delta += (now - lastTime) / timePerTick;
        timer += now - lastTime;
        lastTime = now;

        if (delta >= 1) {
            tick();
            render();
            ticks++;
            delta--;
        }

        if (timer >= 1000000000) {
            System.out.println("Ticks and Frames: " + ticks);
            ticks = 0;
            timer = 0;
        }
    }

}
